﻿$(function () {
    //ユーザー機能作成
    _user.main();
    //右側の絵図機能起動
    _mxClient.main();
    //左側のツリー作成
    _leftTree.main();
    //ヒップアップ作成
    _dailog.main();
});

//mxGraphを扱う事に関するメソッド
var _mxClient = {
    main: function () {
        _mxClient.graph = mxMain();
        _mxClient.fireMouseEvent();
        _mxClient.createCellDbClickEvent();
        _mxClient.createForeignKeyEvent();
        _mxClient.createMouseWheelEvent();
        _mxClient.createGraphScapeEvent();
        _mxClient.createGraphContentChangeEvent();
        _mxClient.createGraphRefreshEvent();

        _mxClient.load();
    },
    //graph対象
    graph: null,
    graphX: 0,//マウスのx軸
    graphY: 0,//マウスのy軸
    tableDefaultWidth: 150,//テーブルの幅
    tableDefaultHeight: 150,//テーブルの長さ
    //データ対象
    data: {
        tables: [
            {
                id: 'table_1',
                name: '試験テーブル_1',
                x: 200,
                y: 150,
                width: 150,
                height: 200,
                columns: [
                    {
                        id: 'studentId',
                        name: '学生番号',
                        isPk: true,
                        type: 'int',
                        length: 4,
                        isNull: false
                    },
                    {
                        id: 'classId',
                        name: 'クラス番号',
                        isPk: false,
                        type: 'int',
                        length: 4,
                        isNull: false
                    }
                ]
            },
            {
                id: 'table_2',
                name: '試験テーブル_2',
                x: 500,
                y: 100,
                width: 150,
                height: 150,
                columns: [
                    {
                        id: 'classId',
                        name: 'クラス番号',
                        isPk: true,
                        type: 'int',
                        length: 4,
                        isNull: false
                    },
                    {
                        id: 'className',
                        name: 'クラス名',
                        isPk: false,
                        type: 'int',
                        length: 4,
                        isNull: false
                    }
                ],
            },
            {
                id: 'table_3',
                name: '試験テーブル_3',
                x: 360,
                y: 470,
                width: 150,
                height: 150,
                columns: [
                    {
                        id: 'classId',
                        name: 'クラス番号',
                        isPk: true,
                        type: 'int',
                        length: 4,
                        isNull: false
                    },
                    {
                        id: 'className',
                        name: 'クラス名',
                        isPk: false,
                        type: 'int',
                        length: 4,
                        isNull: false
                    }
                ],
            }
        ],
        foreignKeys: [
            {
                id: 'foreignKey_1',
                name: '試験テーブル_1と試験テーブル_2',
                sourceTableId: 'table_1',
                sourceTableColumnId: 'classId',
                targetTableId: 'table_2',
                targetTableColumnId: 'classId'
            },
            {
                id: 'foreignKey_2',
                name: '試験テーブル_1と試験テーブル_3',
                sourceTableId: 'table_1',
                sourceTableColumnId: 'classId',
                targetTableId: 'table_3',
                targetTableColumnId: 'classId'
            }
        ],
        indexs: [],
        constraints: []
    },
    load: function () {
        var graph = _mxClient.graph;
        var data = _mxClient.data;
        var model = graph.getModel();

        // Adds cells to the model in a single step
        var width = _mxClient.tableDefaultWidth;
        var height = _mxClient.tableDefaultHeight;
        
        //table作成
        var tables = data.tables;
        for (var i = 0; i < tables.length; i++) {
            var tableData = tables[i];
            _mxClient.insertTable(tableData);
        }

        //foreignKey作成
        var foreignKeys = data.foreignKeys;
        for (var i = 0; i < foreignKeys.length; i++) {
            var foreignKeyData = foreignKeys[i];
            _mxClient.insertForeignKey(foreignKeyData);
        }
    },
    save: function () {
        var graph = _mxClient.graph;
        var data = _mxClient.saveData;

    },
    //mxGraphの内容変更イベント
    createGraphContentChangeEvent: function () {
        var graph = _mxClient.graph;

        graph.getModel().addListener(mxEvent.CHANGE, function (sender, evt) {
            _leftTree.createTree();
        });
    },
    //mxGraphの内容リフレッシュイベント
    createGraphRefreshEvent: function () {
        var graph = _mxClient.graph;

        graph.addListener(mxEvent.REFRESH, function (sender, evt) {
            _leftTree.createTree();
        });
    },
    //マウスの座標を取得（ロジック的、座標原点オフセットが含まれる）
    fireMouseEvent: function () {
        var graph = _mxClient.graph;

        graph.fireMouseEvent = function (evtName, me, sender) {
            mxGraph.prototype.fireMouseEvent.apply(this, arguments);
            //座標原点取得
            var point = graph.view.translate;

            //該当マウスの座標取得
            _mxClient.graphX = me.getGraphX() / graph.view.scale - point.x;
            _mxClient.graphY = me.getGraphY() / graph.view.scale - point.y;

        };
    },
    //テーブルモデル
    getTableModel: function (cell) {
        var columns = cell.columns;
        
        var title = $('<table width="100%" border="0" cellpadding="4" class="title">' +
            '   <tr><th colspan="2">' + cell.name + '</th></tr>' +
            '</table>');
        var content = $('<div class="content">' +
            '<table width="100%" height="100%" border="0" cellpadding="4" class="erd">' +
            '</table>' +
            '</div>');
        if (columns) {
            for (var i = 0; i < columns.length; i++) {
                if (columns[i].isPk) {
                    content.find('table').append('<tr><td width="30" height="27"><img align="center" src="mxClient/images/pk.png"/></td><td><u>' + columns[i].name + '</u></td></tr>');
                } else {
                    content.find('table').append('<tr><td width="30" height="27"></td><td><u>' + columns[i].name + '</u></td></tr>');
                }
            }
            content.find('table').append('<tr><td></td><td></td></tr>');
        }

        return title.prop("outerHTML") + content.prop("outerHTML");
    },
    //外部キー説明Label取得
    getForeignKeyLabel: function (cell) {
        return cell.name;
    },
    //テーブルの行ごと座標取得
    getTableRowY: function (state, tr) {
        var s = state.view.scale;
        var div = tr.parentNode.parentNode.parentNode;
        var offsetTop = parseInt(div.style.top);
        var y = state.y + (tr.offsetTop + tr.offsetHeight / 2 - div.scrollTop + offsetTop) * s;
        y = Math.min(state.y + state.height, Math.max(state.y + offsetTop * s, y));

        return y;
    },
    //新たなテーブル追加イベント
    addTableEvent: function () {
        var graph = _mxClient.graph;
        //カーソル形設定
        graph.container.style.cursor = 'crosshair';

        //テーブル追加イベント設定
        graph.addListener(mxEvent.CLICK, _mxClient.addTable);

        //ESCを押したらaddTableの扱いをキャンセルイベント設定
        mxEvent.addListener(window, "keydown", function (evt) {
            if (evt.keyCode == 27) {
                _mxClient.cancelAddTable();
            }
        });

    },
    //新たなテーブル追加
    addTable: function (sender, evt) {
        var graph = _mxClient.graph;
        var model = graph.getModel();

        var cell = evt.getProperty('cell');
        if (cell == null) {
            var parent = graph.getDefaultParent();

            var tableData = _mxClient.createNewTableData('table_' + model.nextId, 'table_' + model.nextId);
            _mxClient.insertTable(tableData);
            evt.consume();

            //テーブル追加したので、イベントを削除し、カーソルも元にする
            _mxClient.cancelAddTable();
        }
    },
    //新たなテーブル追加することをキャンセル
    cancelAddTable: function () {
        var graph = _mxClient.graph;

        graph.removeListener(_mxClient.addTable);
        if (graph.container.style.cursor == 'crosshair') {
            graph.container.style.cursor = '';
        }
    },
    //新たな外部キー追加（マウスドラッグ＆ドロップ）、テーブルの追加もトリガーされたので、外部キーの処理を判断するのが必要です
    createForeignKeyEvent: function () {
        var graph = _mxClient.graph;
        var model = graph.getModel();

        graph.connectionHandler.mouseUp = function (sender, me) {
            if (this.edgeState != null) {
                //BUGです、必須
                this.factoryMethod = null;

                var sourceCell = (this.previous != null) ? this.previous.cell : null;
                var targetCell = null;
                if (this.constraintHandler.currentConstraint != null &&
                    this.constraintHandler.currentFocus != null) {
                    targetCell = this.constraintHandler.currentFocus.cell;
                }
                if (targetCell == null && this.currentState != null) {
                    targetCell = this.currentState.cell;
                }
                var cell = this.edgeState.cell;
                var relation = cell.value;

                if (sourceCell != targetCell &&
                    sourceCell != null && sourceCell.edges != null &&
                    targetCell != null && targetCell.edges != null) {

                    var sourceHas = false;
                    var targetHas = false;

                    //元テーブルに同じ列番を持ってるrelationが既に存在した
                    for (var i = 0; i < sourceCell.edges.length; i++) {
                        if (sourceCell.edges[i].source == sourceCell &&
                            sourceCell.edges[i].value.attributes.sourceRow.value == relation.attributes.sourceRow.value &&
                            sourceCell.edges[i].value.attributes.targetRow.value == relation.attributes.targetRow.value) {
                            sourceHas = true;
                            break;
                        }
                    }
                    //目標テーブルに同じ列番を持ってるrelationが既に存在した
                    for (var i = 0; i < targetCell.edges.length; i++) {
                        if (targetCell.edges[i].target == targetCell &&
                            targetCell.edges[i].value.attributes.sourceRow.value == relation.attributes.sourceRow.value &&
                            targetCell.edges[i].value.attributes.targetRow.value == relation.attributes.targetRow.value) {
                            targetHas = true;
                            break;
                        }
                    }
                    //元テーブルと目標テーブル両方もtrueの場合、キャンセル
                    if (sourceHas && targetHas) {
                        alert("edgeは既に存在しました");
                    } else {
                        var foreignKeyData = _mxClient.createNewForeignKeyData(
                            'foreignKey_' + model.nextId,
                            'foreignKey_' + model.nextId,
                            sourceCell.id,
                            sourceCell.columns[parseInt(relation.attributes.sourceRow.value) - 1].id,
                            targetCell.id,
                            targetCell.columns[parseInt(relation.attributes.targetRow.value) - 1].id
                        );
                        _mxClient.insertForeignKey(foreignKeyData);
                    }
                }
                this.reset();
            }
        };
    },
    //テーブルのダブルクリックイベント
    createCellDbClickEvent: function () {
        var graph = _mxClient.graph;

        graph.addListener(mxEvent.DOUBLE_CLICK, function (sender, evt) {
            var cell = evt.getProperty('cell');
            if (cell.edge) {
                _dailog.vmForeignKey.open(cell);
            } else if (cell.vertex) {
                _dailog.vmTable.open(cell);
            }
            evt.consume();
        });
    },
    //マウスのスクロールイベント
    createMouseWheelEvent: function () {
        var graph = _mxClient.graph;

        mxEvent.addMouseWheelListener(function (evt, delta) {
            //ctrlを押している際だけで実行
            if (evt.ctrlKey) {
                if (delta) {
                    graph.zoomIn();
                } else {
                    graph.zoomOut();
                }
                evt.preventDefault();
            }
        });
    },
    //スペースキーを押して、画面を移動できるイベント
    createGraphScapeEvent: function () {
        var graph = _mxClient.graph;

        mxEvent.addListener(window, "keydown", function (evt) {
            if (evt.keyCode == 32) {
                _mxClient.cancelAddTable();
                if (!graph.panningHandler.useLeftButtonForPanning) {
                    graph.panningHandler.useLeftButtonForPanning = true;
                    graph.panningHandler.ignoreCell = true;
                    graph.container.style.cursor = 'move';
                    graph.setPanning(true);
                }
                evt.preventDefault();
            }
        });
        mxEvent.addListener(window, "keyup", function (evt) {
            if (evt.keyCode == 32) {
                graph.panningHandler.useLeftButtonForPanning = false;
                graph.panningHandler.ignoreCell = false;
                graph.container.style.cursor = '';
                graph.setPanning(false);
            }
        });
    },
    //graphの中にcells数取得
    getCellsLength: function (cells) {
        var length = 0;
        for (var item in cells) {
            length++;
        }
        return length;
    },
    //新テーブルJsonオブジェクト作成
    createNewTableData: function (id, name) {
        var tableData = {
            id: id,
            name: name,
            x: _mxClient.graphX,
            y: _mxClient.graphY,
            width: _mxClient.tableDefaultWidth,
            height: _mxClient.tableDefaultHeight,
            columns: []
        };
        return tableData;
    },
    //新テーブルの列Jsonオブジェクト作成
    createNewTableColumnData: function (id, name) {
        var tableColumnData = {
            id: !id ? '' : id,
            name: !name ? '' : name,
            isPk: false,
            type: '',
            length: 0,
            isNull: false
        };
        return tableColumnData;
    },
    //テーブルデータのディープコピー
    deepCopyTableData: function (target, source) {
        target.id = source.id;
        target.name = source.name;
        target.columns = JSON.parse(JSON.stringify(source.columns));
    },
    //graphにテーブルを挿入
    insertTable: function (tableData) {
        var graph = _mxClient.graph;
        var model = graph.getModel();
        // Gets the default parent for inserting new cells. This
        // is normally the first child of the root (ie. layer 0).
        var parent = graph.getDefaultParent();
        model.beginUpdate();
        try {
            var cell = graph.insertVertex(parent, tableData.id, '', tableData.x, tableData.y, tableData.width, tableData.height);
            cell.name = tableData.name;
            cell.columns = tableData.columns;
        }
        finally {
            // Updates the display
            model.endUpdate();
        }
    },
    //graphにテーブルを改修
    updateTable: function (cell, tableDate) {

    },
    //新外部キーJsonオブジェクト作成
    createNewForeignKeyData: function (id, name, sourceTableId, sourceTableColumnId, targetTableId, targetTableColumnId) {
        var foreignKeyData = {
            id: id,
            name: name,
            sourceTableId: sourceTableId,
            sourceTableColumnId: sourceTableColumnId,
            targetTableId: targetTableId,
            targetTableColumnId: targetTableColumnId
        };
        return foreignKeyData;
    },
    //graphに外部キーを挿入
    insertForeignKey: function (foreignKeyData) {
        var graph = _mxClient.graph;
        var model = graph.getModel();
        // User objects (data) for the individual cells
        var doc = mxUtils.createXmlDocument();
        // Gets the default parent for inserting new cells. This
        // is normally the first child of the root (ie. layer 0).
        var parent = graph.getDefaultParent();
        model.beginUpdate();
        try {
            var sourceCell = graph.getModel().getCell(foreignKeyData.sourceTableId);
            var targetCell = graph.getModel().getCell(foreignKeyData.targetTableId);

            var relation = doc.createElement('Relation');
            relation.setAttribute('sourceRow', (sourceCell.columns.findIndex((x) => x.id == foreignKeyData.sourceTableColumnId) + 1).toString());
            relation.setAttribute('targetRow', (targetCell.columns.findIndex((x) => x.id == foreignKeyData.targetTableColumnId) + 1).toString());
            var e1 = graph.insertEdge(parent, foreignKeyData.id, relation, sourceCell, targetCell);
            e1.name = foreignKeyData.name;

            //console.log(e1)
        }
        finally {
            // Updates the display
            model.endUpdate();
        }

    },
    //graphに外部キーを改修
    updateForeignKey: function (cell, foreignKeyData) {
        cell.name = foreignKeyData.name;
    },
    refresh: function (cell) {
        var graph = _mxClient.graph;

        graph.refresh(cell);
    }
}

//ヒップアップに関するメソッド
var _dailog = {
    main: function () {
        _dailog.createVmTable();
        _dailog.createVmForeignKey();
    },
    vmTable: null,
    vmForeignKey: null,
    //ヒップアップのテーブル変更イベント
    createVmTable: function () {
        _dailog.vmTable = new Vue({
            el: '#tableModal',
            data: {
                mxCell: new Object(),
                oldTableData: new Object()
            },
            methods: {
                open: function (mxCell) {
                    this.mxCell = mxCell;
                    _mxClient.deepCopyTableData(this.oldTableData, mxCell);
                    $(this.$options.el).modal('show');
                },
                save: function () {
                    $(this.$options.el).modal('hide');
                    _mxClient.refresh();
                },
                cancel: function () {
                    var mxClient = this.mxCell;
                    for (key in this.oldTableData) {
                        mxClient[key] = this.oldTableData[key];
                    }
                },
                isPkClick: function (column) {
                    var mxClient = this.mxCell;
                    var columns = mxClient.columns;
                    for (var i = 0; i < columns.length; i++) {
                        columns[i].isPk = false;
                    }
                    column.isPk = true;
                },
                addColumn: function () {
                    var mxClient = this.mxCell;
                    var columns = mxClient.columns;
                    columns.push(_mxClient.createNewTableColumnData());
                },
                insertColumn: function () {
                    var mxClient = this.mxCell;
                    var columns = mxClient.columns;

                },
                delColumn: function () {
                    var mxClient = this.mxCell;
                    var columns = mxClient.columns;

                }
            }
        })
    },
    //ヒップアップの外部キー変更イベント
    createVmForeignKey: function () {
        _dailog.vmForeignKey = new Vue({
            el: '#foreignKeyModal',
            data: {
                mxCell: new Object()
            },
            methods: {
                open: function (mxCell) {
                    this.mxCell = mxCell;
                    $(this.$options.el).modal('show');
                },
                save: function () {
                    $(this.$options.el).modal('hide');
                    _mxClient.refresh();
                }
            }
        })
    }
}

//他のユーザー動画
var _user = {
    main: function () {
        _user.topMenu();
        _user.entityMenu();
    },
    //上のメニュー
    topMenu: function () {
        var topMenu = $('#topMenu');
        var titleList = topMenu.find('.bar>li');
        titleList.mouseenter(function () {
            $(this).first('a').css({ backgroundColor: '#efefef' });
            $(this).find('ul').slideDown(100);
        });
        titleList.mouseleave(function () {
            $(this).first('a').css({ backgroundColor: '' });
            $(this).find('ul').hide();
        });
    },
    //エンティティメニュー
    entityMenu: function(){
        var entitys = $('#entitys');
        var aList = entitys.find('ul li a');
        //テーブル作成
        $(aList[0]).click(function () {
            _mxClient.addTableEvent();
        });
    }
}

//左側に関するメソッド
var _leftTree = {
    main: function () {
        _leftTree.init();
        $(window).resize(function () {
            _leftTree.init();
        });
    },
    tableList: new Array(),
    foreignKeyList: new Array(),
    indexList: new Array(),
    constraintList: new Array(),
    init: function () {
        $('#leftMenu').height(document.body.offsetHeight - document.getElementById('topMenu').offsetHeight - 1);
        $('#leftMenu .content').height($('#leftMenu').height() - $('#leftMenu .title').height() - 1);
    },
    createTree: function () {
        _leftTree.createTableList();
        _leftTree.createForeignKeyList();
        _leftTree.createIndexList();
        _leftTree.createConstraintList();
    },
    //テーブル関係項目作成
    createTableList: function () {
        var graph = _mxClient.graph;

        var table = $('#leftMenu #table');
        table.find('ul').remove();
        var ul = $('<ul class="file"></ul>');
        for (var item in graph.model.cells) {
            if (item == '0' || item == '1') {
                continue;
            }
            var cell = graph.model.cells[item];
            if (cell.edge) {
                continue;
            }
            var li = $('<li><a href="javascript:void(0);" title="' +
                cell.name +
                '"><span class="line"></span><span class="line"><span class="hline"></span></span><span><i class="glyphicon glyphicon-file"></i> ' +
                cell.name +
                '</span></a></li>');
            (function (cell) {
                li.dblclick(function () {
                    _dailog.vmTable.open(cell);
                });
            })(cell);
            ul.append(li);
        }

        table.append(ul);
    },
    //外部キー関係項目作成
    createForeignKeyList: function () {
        var graph = _mxClient.graph;

        var foreignKey = $('#leftMenu #foreignKey');
        foreignKey.find('ul').remove();
        var ul = $('<ul class="file"></ul>');
        for (var item in graph.model.cells) {
            if (item == '0' || item == '1') {
                continue;
            }
            var cell = graph.model.cells[item];
            if (cell.vertex) {
                continue;
            }
            var li = $('<li><a href="javascript:void(0);" title="' +
                cell.name +
                '"><span class="line"></span><span class="line"><span class="hline"></span></span><span><i class="glyphicon glyphicon-file"></i> ' +
                cell.name +
                '</span></a></li>');
            (function (cell) {
                li.dblclick(function () {
                    _dailog.vmForeignKey.open(cell);
                })
            })(cell);
            ul.append(li);
        }

        foreignKey.append(ul);

    },
    //インデックス関係項目作成
    createIndexList: function () {
        var graph = _mxClient.graph;
        var index = $('#leftMenu #index');
        
    },
    //制約関係項目作成
    createConstraintList: function () {
        var graph = _mxClient.graph;
        var constraint = $('#leftMenu #constraint');

    }
}

//mxGraphのメインメソッド
// Program starts here. Creates a sample graph in the
// DOM node with the specified ID. This function is invoked
// from the onLoad event handler of the document (see below).
function mxMain() {
    var container = document.getElementById('graphContainer');

    // Checks if the browser is supported
    if (!mxClient.isBrowserSupported()) {
        // Displays an error message if the browser is not supported.
        mxUtils.error('Browser is not supported!', 200, false);
    }
    else {
        // Must be disabled to compute positions inside the DOM tree of the cell label.
        mxGraphView.prototype.optimizeVmlReflows = true;

        // If connect preview is not moved away then getCellAt is used to detect the cell under
        // the mouse if the mouse is over the preview shape in IE (no event transparency), ie.
        // the built-in hit-detection of the HTML document will not be used in this case. This is
        // not a problem here since the preview moves away from the mouse as soon as it connects
        // to any given table row. This is because the edge connects to the outside of the row and
        // is aligned to the grid during the preview.
        mxConnectionHandler.prototype.movePreviewAway = false;

        // Disables foreignObjects
        mxClient.NO_FO = true;

        // Enables move preview in HTML to appear on top
        mxGraphHandler.prototype.htmlPreview = true;

        // Enables connect icons to appear on top of HTML
        mxConnectionHandler.prototype.moveIconFront = true;

        // Defines an icon for creating new connections in the connection handler.
        // This will automatically disable the highlighting of the source vertex.
        mxConnectionHandler.prototype.connectImage = new mxImage('mxClient/images/connector.gif', 16, 16);

        // ヒップアップ
        var outline = document.getElementById('outlineContainer');

        // Support for certain CSS styles in quirks mode
        if (mxClient.IS_QUIRKS) {
            new mxDivResizer(container);
            new mxDivResizer(outline);
        }

        // Disables the context menu
        mxEvent.disableContextMenu(container);

        // Overrides target perimeter point for connection previews
        mxConnectionHandler.prototype.getTargetPerimeterPoint = function (state, me) {
            // Determines the y-coordinate of the target perimeter point
            // by using the currentRowNode assigned in updateRow
            var y = me.getY();

            if (this.currentRowNode != null) {
                y = _mxClient.getTableRowY(state, this.currentRowNode);
            }

            // Checks on which side of the terminal to leave
            var x = state.x;

            if (this.previous.getCenterX() > state.getCenterX()) {
                x += state.width;
            }

            return new mxPoint(x, y);
        };

        // Overrides source perimeter point for connection previews
        mxConnectionHandler.prototype.getSourcePerimeterPoint = function (state, next, me) {
            var y = me.getY();

            if (this.sourceRowNode != null) {
                y = _mxClient.getTableRowY(state, this.sourceRowNode);
            }

            // Checks on which side of the terminal to leave
            var x = state.x;

            if (next.x > state.getCenterX()) {
                x += state.width;
            }

            return new mxPoint(x, y);
        };

        // Disables connections to invalid rows
        mxConnectionHandler.prototype.isValidTarget = function (cell) {
            return this.currentRowNode != null;
        };

        // Creates the graph inside the given container
        //var graph = new mxGraph(container);
        var config = mxUtils.load(
            'mxClient/config/keyhandler-commons.xml').
            getDocumentElement();
        var editor = new mxEditor(config);
        editor.setGraphContainer(container);
        var graph = editor.graph;
        var model = graph.getModel();

        // User objects (data) for the individual cells
        var doc = mxUtils.createXmlDocument();

        // Uses the entity perimeter (below) as default
        graph.stylesheet.getDefaultVertexStyle()[mxConstants.STYLE_VERTICAL_ALIGN] = mxConstants.ALIGN_TOP;
        graph.stylesheet.getDefaultVertexStyle()[mxConstants.STYLE_PERIMETER] =
            mxPerimeter.EntityPerimeter;
        //graph.stylesheet.getDefaultVertexStyle()[mxConstants.STYLE_SHADOW] = true;
        graph.stylesheet.getDefaultVertexStyle()[mxConstants.STYLE_FILLCOLOR] = '#fff';
        //graph.stylesheet.getDefaultVertexStyle()[mxConstants.STYLE_GRADIENTCOLOR] = '#def';
        graph.stylesheet.getDefaultVertexStyle()[mxConstants.STYLE_STROKECOLOR] = '#ccc';
        graph.stylesheet.getDefaultVertexStyle()[mxConstants.STYLE_STROKEWIDTH] = '1';

        // Used for HTML labels that use up the complete vertex space (see
        // graph.cellRenderer.redrawLabel below for syncing the size)
        graph.stylesheet.getDefaultVertexStyle()[mxConstants.STYLE_OVERFLOW] = 'fill';

        // Uses the entity edge style as default
        graph.stylesheet.getDefaultEdgeStyle()[mxConstants.STYLE_EDGE] =
            mxEdgeStyle.EntityRelation;
        graph.stylesheet.getDefaultEdgeStyle()[mxConstants.STYLE_STROKECOLOR] = 'black';
        graph.stylesheet.getDefaultEdgeStyle()[mxConstants.STYLE_FONTCOLOR] = 'black';

        // Allows new connections to be made but do not allow existing
        // connections to be changed for the sake of simplicity of this
        // example
        graph.setCellsDisconnectable(false);
        graph.setAllowDanglingEdges(false);
        graph.setCellsEditable(false);
        graph.setConnectable(true);
        graph.setPanning(true);
        graph.centerZoom = true;
        graph.keepSelectionVisibleOnZoom = true;

        // Creates the outline (navigator, overview) for moving
        // around the graph in the top, right corner of the window.
        var outln = new mxOutline(graph, outline);

        // Overrides connectable state
        graph.isCellConnectable = function (cell) {
            return !this.isCellCollapsed(cell);
        };

        // Enables HTML markup in all labels
        graph.setHtmlLabels(true);

        // Scroll events should not start moving the vertex
        graph.cellRenderer.isLabelEvent = function (state, evt) {
            var source = mxEvent.getSource(evt);

            return state.text != null && source != state.text.node &&
                source != state.text.node.getElementsByTagName('div')[0];
        };

        // Adds scrollbars to the outermost div and keeps the
        // DIV position and size the same as the vertex
        var oldRedrawLabel = graph.cellRenderer.redrawLabel;
        graph.cellRenderer.redrawLabel = function (state) {
            oldRedrawLabel.apply(this, arguments); // "supercall"
            var graph = state.view.graph;
            var model = graph.model;

            if (model.isVertex(state.cell) && state.text != null) {
                // Scrollbars are on the div
                var s = graph.view.scale;
                state.text.node.style.overflow = 'hidden';
                var div = state.text.node.getElementsByTagName('div')[0];

                if (div != null) {
                    // Adds height of the title table cell
                    var oh = 26;

                    div.style.display = 'block';
                    div.style.top = oh + 'px';
                    div.style.width = Math.max(1, Math.round(state.width / s)) + 1 + 'px';
                    div.style.height = Math.max(1, Math.round((state.height / s) - oh)) + 'px';

                    // Installs the handler for updating connected edges
                    if (div.scrollHandler == null) {
                        div.scrollHandler = true;

                        var updateEdges = mxUtils.bind(this, function () {
                            var edgeCount = model.getEdgeCount(state.cell);
                            // Only updates edges to avoid update in DOM order
                            // for text label which would reset the scrollbar
                            for (var i = 0; i < edgeCount; i++) {
                                var edge = model.getEdgeAt(state.cell, i);
                                graph.view.invalidate(edge, true, false);
                                graph.view.validate(edge);
                            }
                        });

                        mxEvent.addListener(div, 'scroll', updateEdges);
                        mxEvent.addListener(div, 'mouseup', updateEdges);
                    }
                }
            }
        };

        // Adds a new function to update the currentRow based on the given event
        // and return the DOM node for that row
        graph.connectionHandler.updateRow = function (target) {
            while (target != null && target.nodeName != 'TR') {
                target = target.parentNode;
            }

            this.currentRow = null;
            var trArr = target != null ? target.parentNode.getElementsByTagName('tr') : null;

            // Checks if we're dealing with a row in the correct table
            if (target != null && target.parentNode.parentNode.className == 'erd' && trArr[trArr.length - 1] != target) {
                // Stores the current row number in a property so that it can
                // be retrieved to create the preview and final edge
                var rowNumber = 0;
                var current = target.parentNode.firstChild;

                while (target != current && current != null) {
                    current = current.nextSibling;
                    rowNumber++;
                }

                this.currentRow = rowNumber + 1;
            }
            else {
                target = null;
            }

            return target;
        };

        // Adds placement of the connect icon based on the mouse event target (row)
        graph.connectionHandler.updateIcons = function (state, icons, me) {
            var target = me.getSource();
            target = this.updateRow(target);
            var trArr = target!=null ? target.parentNode.getElementsByTagName('tr') : null;

            if (target != null && this.currentRow != null && trArr[trArr.length - 1] != target) {
                var div = target.parentNode.parentNode.parentNode;
                var s = state.view.scale;

                icons[0].node.style.visibility = 'visible';
                icons[0].bounds.x = state.x + target.offsetLeft + Math.min(state.width,
                    target.offsetWidth * s) - this.icons[0].bounds.width - 2;
                icons[0].bounds.y = state.y - this.icons[0].bounds.height / 2 + (target.offsetTop +
                    target.offsetHeight / 2 - div.scrollTop + div.offsetTop) * s;
                icons[0].redraw();

                this.currentRowNode = target;
            }
            else {
                icons[0].node.style.visibility = 'hidden';
            }
        };

        // Updates the targetRow in the preview edge State
        var oldMouseMove = graph.connectionHandler.mouseMove;
        graph.connectionHandler.mouseMove = function (sender, me) {
            if (this.edgeState != null) {
                this.currentRowNode = this.updateRow(me.getSource());

                if (this.currentRow != null) {
                    this.edgeState.cell.value.setAttribute('targetRow', this.currentRow);
                }
                else {
                    this.edgeState.cell.value.setAttribute('targetRow', '0');
                }

                // Destroys icon to prevent event redirection via image in IE
                this.destroyIcons();
            }

            oldMouseMove.apply(this, arguments);
        };

        // Creates the edge state that may be used for preview
        graph.connectionHandler.createEdgeState = function (me) {
            var relation = doc.createElement('Relation');
            relation.setAttribute('sourceRow', this.currentRow || '0');
            relation.setAttribute('targetRow', '0');

            var edge = this.createEdge(relation);
            edge.value = relation;
            var style = this.graph.getCellStyle(edge);
            var state = new mxCellState(this.graph.view, edge, style);

            // Stores the source row in the handler
            this.sourceRowNode = this.currentRowNode;

            return state;
        };

        // Overrides getLabel to return empty labels for edges and
        // short markup for collapsed cells.
        graph.getLabel = function (cell) {
            if (this.getModel().isVertex(cell)) {
                return _mxClient.getTableModel(cell);
            }
            else if (this.getModel().isEdge(cell)) {
                return _mxClient.getForeignKeyLabel(cell);
            }else {
                return '';
            }
        };

        //線のスタイル変更
        var style = graph.getStylesheet().getDefaultEdgeStyle();
        style[mxConstants.STYLE_EDGE] = mxEdgeStyle.EntityRelation;
        style[mxConstants.STYLE_ENDARROW] = mxConstants.ARROW_BLOCK;
        style[mxConstants.STYLE_ROUNDED] = true;
        style[mxConstants.STYLE_FONTCOLOR] = 'black';
        style[mxConstants.STYLE_STROKECOLOR] = 'black';
    }

    return graph;
};
// Implements a special perimeter for table rows inside the table markup
mxGraphView.prototype.updateFloatingTerminalPoint = function (edge, start, end, source) {
    var next = this.getNextPoint(edge, end, source);
    if (start.text == null)
        return;
    var div = start.text.node.getElementsByTagName('div')[0];

    var x = start.x;
    var y = start.getCenterY();

    // Checks on which side of the terminal to leave
    if (next.x > x + start.width / 2) {
        x += start.width;
    }

    if (div != null) {
        y = start.getCenterY() - div.scrollTop;

        if (mxUtils.isNode(edge.cell.value) && !this.graph.isCellCollapsed(start.cell)) {
            var attr = (source) ? 'sourceRow' : 'targetRow';
            var row = parseInt(edge.cell.value.getAttribute(attr));

            // HTML labels contain an outer table which is built-in
            var table = div.getElementsByTagName('table')[0];
            var trs = table.getElementsByTagName('tr');
            var tr = trs[Math.min(trs.length - 1, row - 1)];

            // Gets vertical center of source or target row
            if (tr != null) {
                y = _mxClient.getTableRowY(start, tr);
            }
        }

        // Keeps vertical coordinate inside start
        var offsetTop = parseInt(div.style.top) * start.view.scale;
        y = Math.min(start.y + start.height, Math.max(start.y + offsetTop, y));

        // Updates the vertical position of the nearest point if we're not
        // dealing with a connection preview, in which case either the
        // edgeState or the absolutePoints are null
        if (edge != null && edge.absolutePoints != null) {
            next.y = y;
        }
    }

    edge.setAbsoluteTerminalPoint(new mxPoint(x, y), source);

    // Routes multiple incoming edges along common waypoints if
    // the edges have a common target row
    if (source && mxUtils.isNode(edge.cell.value) && start != null && end != null) {
        var edges = this.graph.getEdgesBetween(start.cell, end.cell, true);
        var tmp = [];

        // Filters the edges with the same source row
        var row = edge.cell.value.getAttribute('targetRow');

        for (var i = 0; i < edges.length; i++) {
            if (mxUtils.isNode(edges[i].value) &&
                edges[i].value.getAttribute('targetRow') == row) {
                tmp.push(edges[i]);
            }
        }

        edges = tmp;

        if (edges.length > 1 && edge.cell == edges[edges.length - 1]) {
            // Finds the vertical center
            var states = [];
            var y = 0;

            for (var i = 0; i < edges.length; i++) {
                states[i] = this.getState(edges[i]);
                y += states[i].absolutePoints[0].y;
            }

            y /= edges.length;

            for (var i = 0; i < states.length; i++) {
                var x = states[i].absolutePoints[1].x;

                if (states[i].absolutePoints.length < 5) {
                    states[i].absolutePoints.splice(2, 0, new mxPoint(x, y));
                }
                else {
                    states[i].absolutePoints[2] = new mxPoint(x, y);
                }

                // Must redraw the previous edges with the changed point
                if (i < states.length - 1) {
                    this.graph.cellRenderer.redraw(states[i]);
                }
            }
        }
    }
};
// Defines global helper function to get y-coordinate for a given cell state and row
